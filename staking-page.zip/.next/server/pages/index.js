const CHUNK_PUBLIC_PATH = "server/pages/index.js";
const runtime = require("../chunks/ssr/[turbopack]_runtime.js");
runtime.loadChunk("server/chunks/ssr/[root of the server]__53787a._.js");
runtime.loadChunk("server/chunks/ssr/node_modules_next_b9edbd._.js");
runtime.loadChunk("server/chunks/ssr/node_modules_@mui_material_764420._.js");
runtime.loadChunk("server/chunks/ssr/node_modules_@mui_system_esm_3ae43a._.js");
runtime.loadChunk("server/chunks/ssr/node_modules_e0c334._.js");
runtime.loadChunk("server/chunks/ssr/src_styles_globals_070f83.css");
module.exports = runtime.getOrInstantiateRuntimeModule("[project]/node_modules/next/dist/esm/build/templates/pages.js { INNER_PAGE => \"[project]/src/pages/index.tsx [ssr] (ecmascript)\", INNER_DOCUMENT => \"[project]/src/pages/_document.tsx [ssr] (ecmascript)\", INNER_APP => \"[project]/src/pages/_app.tsx [ssr] (ecmascript)\" } [ssr] (ecmascript)", CHUNK_PUBLIC_PATH).exports;
