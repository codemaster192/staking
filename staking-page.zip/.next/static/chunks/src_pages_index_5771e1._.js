(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_pages_index_5771e1._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_pages_index_5771e1._.js",
  "chunks": [
    "static/chunks/[root of the server]__f277e3._.js",
    "static/chunks/node_modules_next_0b95da._.js",
    "static/chunks/node_modules_react-dom_82bb97._.js",
    "static/chunks/node_modules_@mui_material_9cd7ad._.js",
    "static/chunks/node_modules_@mui_system_esm_3db0d0._.js",
    "static/chunks/node_modules_ethers_lib_esm_3a0710._.js",
    "static/chunks/node_modules_@noble_curves_esm_defa77._.js",
    "static/chunks/node_modules_05f87b._.js"
  ],
  "source": "entry"
});
